<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Session;

class UsersController extends Controller
{
    public function create()
    {
        return view('create');
    }


    public function dashboard()
    {
        return view('dashboard');
    }

    public function loginsubmit(Request $req)
    {
         User::select('*')->where(
            [
                ['email', '=', $req->email],
                ['password', '=', $req->password],
            ]
        )->get();
       
        return redirect('/dashboard');
    }

    public function createsubmit(Request $req)
    {
        $user = new User();
        $user->username=$req->username;
        $user->email=$req->email;
        $user->password=$req->password;
        $result=$user->save();
        if($result)
        {
           
            return redirect('/');
        }
    }
}
