<?php

namespace App\Http\Controllers;

use App\Models\HospitalSattings;
use App\Http\Requests\StoreHospitalSattingsRequest;
use App\Http\Requests\UpdateHospitalSattingsRequest;

class HospitalSattingsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreHospitalSattingsRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreHospitalSattingsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\HospitalSattings  $hospitalSattings
     * @return \Illuminate\Http\Response
     */
    public function show(HospitalSattings $hospitalSattings)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\HospitalSattings  $hospitalSattings
     * @return \Illuminate\Http\Response
     */
    public function edit(HospitalSattings $hospitalSattings)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateHospitalSattingsRequest  $request
     * @param  \App\Models\HospitalSattings  $hospitalSattings
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateHospitalSattingsRequest $request, HospitalSattings $hospitalSattings)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\HospitalSattings  $hospitalSattings
     * @return \Illuminate\Http\Response
     */
    public function destroy(HospitalSattings $hospitalSattings)
    {
        //
    }
}
