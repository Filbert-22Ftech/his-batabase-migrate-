<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ChequeDetailsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
